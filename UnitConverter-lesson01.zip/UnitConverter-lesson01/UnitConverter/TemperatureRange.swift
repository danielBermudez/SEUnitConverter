//
//  TemperaturRange.swift
//  UnitConverter
//
//  Created by Daniel Bermudez on 3/7/19.
//  Copyright © 2019 Your School. All rights reserved.
//

import Foundation
import UIKit
class TemperatureRange {
 
}
